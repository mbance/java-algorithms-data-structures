public class LCG {

	long int_a, int_b, int_c, int_d;

    public LCG(long _a, long _c, long _m, long seed) { 

    	int_a = _a;
    	int_b = _c;
    	int_c = _m;
    	int_d = seed;

    }

    public long next() {
        return int_d = (int_d * int_a + int_b) % int_c;
    }

    public void seed(long seed) { 

    	int_d = seed;

    }
}
